import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-switch',
  templateUrl: './switch.component.html',
  styleUrls: ['./switch.component.scss']
})
export class SwitchComponent implements OnInit {

  enable = true;
  count = 0;

  constructor() { }

  ngOnInit(): void { }

  onSubmit() { }

  onChange() {
    this.count++;
  }

}
